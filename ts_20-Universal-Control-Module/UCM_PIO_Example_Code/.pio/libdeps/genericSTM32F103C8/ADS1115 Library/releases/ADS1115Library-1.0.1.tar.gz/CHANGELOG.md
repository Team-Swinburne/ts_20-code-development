## [1.0.1] - 2020-08-28
 
### Added

Added examples
 
### Changed

Removed some unused variables
   
### Fixed